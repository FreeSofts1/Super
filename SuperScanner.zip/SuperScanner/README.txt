SuperScanner - Instantly scan and destroy viruses.

How to run it?
Open the scanner in the archive itself.
As viruses can delete it if you unzip it.

